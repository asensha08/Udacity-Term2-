#!/bin/bash
# My first script
~/anaconda2/bin/jupyter notebook